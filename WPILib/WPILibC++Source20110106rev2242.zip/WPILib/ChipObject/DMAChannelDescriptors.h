// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __n2EAA5E59CAF1A8A966853A011B61CC91_DMAChannelDescriptors_h__
#define __n2EAA5E59CAF1A8A966853A011B61CC91_DMAChannelDescriptors_h__

#include "tDMAChannelDescriptor.h"

namespace nFPGA
{
namespace n2EAA5E59CAF1A8A966853A011B61CC91
{

   static const int g_DmaVersion = 1;
   static const int g_NumDmaChannels = 1;
   static const tDMAChannelDescriptor g_DMAChannelDescriptors[] =
   {
      // "DMA"
      {
         0,
         0x00007F9C,
         1024,
         1
      },
   };

}
}

#endif // __n2EAA5E59CAF1A8A966853A011B61CC91_DMAChannelDescriptors_h__
