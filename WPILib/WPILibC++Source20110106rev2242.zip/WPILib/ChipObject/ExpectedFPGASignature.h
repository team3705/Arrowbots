// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __n2EAA5E59CAF1A8A966853A011B61CC91_ExpectedFPGASignature_h__
#define __n2EAA5E59CAF1A8A966853A011B61CC91_ExpectedFPGASignature_h__

namespace nFPGA
{
namespace n2EAA5E59CAF1A8A966853A011B61CC91
{

   static const unsigned short g_ExpectedFPGAVersion = 2011;
   static const unsigned int g_ExpectedFPGARevision = 0x00105003;
   static const unsigned int g_ExpectedFPGASignature[] = 
   {
      0x2EAA5E59,
      0xCAF1A8A9,
      0x66853A01,
      0x1B61CC91,
   };

}
}

#endif // __n2EAA5E59CAF1A8A966853A011B61CC91_ExpectedFPGASignature_h__
